<div>
    <div id="activity-card-front">
        <?php echo $__env->make('card.retired.front', ['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div id="activity-card-back">
        <?php echo $__env->make('card.retired.back', ['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <button id="printButton">Imprimir</button>
</div>
<?php /**PATH /Users/inwalter/Laravel/seguridad-v2/resources/views/card/base-card.blade.php ENDPATH**/ ?>