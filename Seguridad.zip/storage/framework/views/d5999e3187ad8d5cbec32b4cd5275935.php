<div class="grid-cols-10 py-12 flex w-full">
    <div class="mx-full sm:px-6 lg:px-8 w-full">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 text-gray-900">

            </div>
        </div>
    </div>
</div><?php /**PATH /Users/inwalter/Laravel/seguridad-v2/resources/views/livewire/main.blade.php ENDPATH**/ ?>