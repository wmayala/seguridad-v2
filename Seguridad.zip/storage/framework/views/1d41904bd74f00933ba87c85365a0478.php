
<img src="<?php echo e(asset('assets/img/logo_bcr.png')); ?>" alt="Logo BCR" width="100px" height="100px">
<?php /**PATH /Users/inwalter/Laravel/seguridad-v2/resources/views/components/application-logo.blade.php ENDPATH**/ ?>