<!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
    <script>
        Swal.fire({
            title: "¡Listo!",
            text: "<?php echo e(session('success')); ?>",
            icon: "success"
        });
    </script>
<?php elseif(session('danger')): ?>
    <script>
        Swal.fire({
            title: "¡Atención!",
            text: "<?php echo e(session('danger')); ?>",
            icon: "error"
        });
    </script>
<?php elseif(session('warning')): ?>
    <script>
        Swal.fire({
            title: "¡Atención!",
            text: "<?php echo e(session('warning')); ?>",
            icon: "warning"
        });
    </script>
<?php elseif(session('delete')): ?>
<script>
    Swal.fire({
        title: "¡Eliminado!",
        text: "<?php echo e(session('delete')); ?>",
        icon: "danger"
    });
</script>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH /Users/inwalter/Laravel/seguridad-v2/resources/views/layouts/notif.blade.php ENDPATH**/ ?>