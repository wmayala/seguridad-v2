<div class="flex overflow-y-auto h-dvh">
    <div class="flex w-full py-6">
        <div class="w-full mx-full sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex justify-between">
                        <?php echo $__env->make('layouts.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="text-[#111e60] text-bold text-3xl mb-5">INSTITUCIONES DEL SISTEMA FINANCIERO</div>
                        <!--[if BLOCK]><![endif]--><?php if(Auth::user()->can('crear-institucion')): ?>
                            <div>
                                <a href="<?php echo e(route('institutions.create')); ?>" class="inline-flex items-center px-4 py-2 bg-[#111e60] border border-transparent rounded-md font-semibold text-md text-white uppercase tracking-widest hover:bg-[#111e60] focus:bg-[#111e60]-700 active:bg-[#111e60]-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">Agregar institución</a>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="flex justify-center my-4">
                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'search','class' => 'w-3/5','wire:model.live' => 'search','placeholder' => 'Escriba la institución a buscar...','autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'search','class' => 'w-3/5','wire:model.live' => 'search','placeholder' => 'Escriba la institución a buscar...','autofocus' => true]); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                    </div>
                    <table class="w-full text-lg text-left text-gray-500 rtl:text-right dark:text-gray-400">
                        <thead class="text-lg text-white uppercase bg-[#111e60] dark:bg-gray-700 dark:text-gray-400">
                            <th class="p-3">NOMBRE DE LA INSTITUCIÓN</th>
                            <th class="p-3">ESTADO</th>
                            <th class="p-3 text-center">ACCIONES</th>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-200 hover:text-[#111e60]">
                                <td class="p-3 text-lg"><?php echo e($institution->name); ?></td>
                                <td class="p-3 text-lg">
                                    <!--[if BLOCK]><![endif]--><?php if($institution->status==1): ?>
                                        <span class="inline-flex items-center px-2 py-1 text-xs text-green-700 uppercase rounded-md bg-green-50 ring-1 ring-inset ring-green-600/20">Activo</span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2 py-1 text-xs text-red-700 uppercase rounded-md bg-red-50 ring-1 ring-inset ring-red-600/10">Inactivo</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td class="text-center">
                                    <?php if(Auth::user()->can('modificar-institucion')): ?>
                                        <button wire:click="redirectTo('institutions.edit',<?php echo e($institution->id); ?>)" class="px-2 py-1 text-white bg-yellow-400 rounded">Editar</button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <?php if(Auth::user()->can('eliminar-institucion')): ?>
                                        <button wire:click="delete(<?php echo e($institution->id); ?>)" class="px-2 py-1 text-white bg-red-400 rounded">Eliminar</button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/inwalter/Laravel/seguridad-v2/resources/views/livewire/institutions/index.blade.php ENDPATH**/ ?>